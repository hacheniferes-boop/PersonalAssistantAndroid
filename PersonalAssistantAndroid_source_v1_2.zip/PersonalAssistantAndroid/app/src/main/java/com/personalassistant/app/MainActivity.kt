package com.personalassistant.app

import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.view.ViewGroup
import android.graphics.Color
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var webView: WebView
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    inner class VoiceBridge {
        @JavascriptInterface
        fun speak(text: String) {
            runOnUiThread {
                if (ttsReady) {
                    tts?.setPitch(1.18f)
                    tts?.setSpeechRate(1.08f)
                    tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "assistant_voice")
                }
            }
        }
        @JavascriptInterface
        fun stop() {
            runOnUiThread { tts?.stop() }
        }
    }

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(23, 37, 84)
        window.navigationBarColor = Color.rgb(23, 37, 84)
        tts = TextToSpeech(this, this)

        webView = WebView(this)
        webView.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        webView.setBackgroundColor(Color.rgb(244, 246, 251))
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = false
            cacheMode = WebSettings.LOAD_DEFAULT
            builtInZoomControls = false
            displayZoomControls = false
        }
        webView.addJavascriptInterface(VoiceBridge(), "AndroidTTS")
        setContentView(webView)
        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("ar", "TN"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                       result != TextToSpeech.LANG_NOT_SUPPORTED
            // Prefer a voice whose engine metadata/name indicates a feminine voice.
            val voices: Set<Voice>? = tts?.voices
            val arabicVoices = voices?.filter {
                it.locale.language == "ar" && !it.isNetworkConnectionRequired
            } ?: emptyList()
            val femaleVoice = arabicVoices.firstOrNull {
                it.name.contains("female", ignoreCase = true) ||
                it.name.contains("woman", ignoreCase = true)
            }
            if (femaleVoice != null) tts?.voice = femaleVoice
            tts?.setPitch(1.18f)
            tts?.setSpeechRate(1.08f)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (this::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }
}
